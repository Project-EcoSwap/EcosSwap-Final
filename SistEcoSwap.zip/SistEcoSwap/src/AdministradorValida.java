import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class AdministradorValida {
    int id;
    String nome;
    String email;
    String senha;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getNome(JTextField txtNome) {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail(JTextField txtEmail) {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha(JPasswordField txtSenha) {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    public int ValidarSenha(String email, String senha){

        String sql = "SELECT * FROM tb_administrador where email = ? and senha = ?";
         ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, senha);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next())
            {
                setNome(rs.getString("nome"));
                setEmail(rs.getString("email"));             
                JOptionPane.showMessageDialog(null, "Olá " + nome);
                TelaInicialAdm telaAdm = new TelaInicialAdm();
                telaAdm.setVisible(true);
                return 0;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Email e/ou Senha Inválido!");
                return 1;
            }            
        }
        catch (Exception e){
        e.printStackTrace();
        return 99;
        
        }
       }
    
}
