
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class UsuarioValida {
    int codigo;
    String nome;
    String email;
    String cep;
    String numEndereco;
    String complementoEndereco;
    String senha;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNumEndereco() {
        return numEndereco;
    }

    public void setNumEndereco(String numEndereco) {
        this.numEndereco = numEndereco;
    }

    public String getComplementoEndereco() {
        return complementoEndereco;
    }

    public void setComplementoEndereco(String complementoEndereco) {
        this.complementoEndereco = complementoEndereco;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    public int ValidarSenha(String email, String senha){

        String sql = "SELECT * FROM tb_usuario where email_cliente = ? and senha_cliente = ?";
         ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, senha);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next())
            {
                setNome(rs.getString("nome_cliente"));
                setEmail(rs.getString("email_cliente"));             
                JOptionPane.showMessageDialog(null, "Seja bem-vindo " + nome);
                TelaInicialUsuario telaUsu = new TelaInicialUsuario();
                telaUsu.setVisible(true);
                return 0;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Email e/ou Senha Inválido!");
                return 1;
            }            
        }
        catch (Exception e){
        e.printStackTrace();
        return 99;
        
        }
       }
    
}
